# Local PDF Text Editor — Chrome extension (Manifest V3)

## First-time setup (Windows)
1. Extract the ZIP.
2. Right-click **setup-dependencies.ps1** > **Run with PowerShell**, or from PowerShell run `powershell -ExecutionPolicy Bypass -File .\setup-dependencies.ps1` inside the extracted directory. Internet access is needed **once** to download PDF.js and pdf-lib.
3. Open `chrome://extensions`, turn on **Developer mode**, click **Load unpacked**, and select the extracted `pdf-editor-extension` folder.
4. Click the extension icon. Select **Open PDF**, edit, and click **Save PDF**.

For macOS/Linux, run `bash setup-dependencies.sh` instead.

## Editing
- **Select text:** click an existing PDF text item, modify it in the dialog, and Apply.
- **Add text:** select Add text, click where the text should go, type, and Apply.
- **Cover area:** select Cover area and drag a rectangle.
- Use **Undo**, **Clear edits**, zoom and page navigation.
- **Save PDF** creates a new PDF. The source file is untouched.

## Important limitations
- Replacing text visually covers the existing text and adds new text. It does **not** modify the original underlying PDF text stream. Covered original text may remain searchable or recoverable. **Never use this for confidential redaction.**
- Text may not match the original font. Replacements do not automatically reflow paragraphs or tables.
- PDF-lib's built-in Helvetica font supports a limited Western character set. Bengali and other Unicode scripts require adding and embedding a custom font, not implemented here.
- Scanned PDFs have no selectable native text; they can still receive added text or cover overlays, but no OCR is included.
- Some encrypted or malformed PDFs cannot be opened or saved.
- Page rotation/crop-box edge cases may affect alignment. Form fields, signatures, annotations and embedded links have not been tested.

## Privacy and security
- The extension reads only files you explicitly open. PDF bytes are processed locally; no upload or remote runtime code.
- `downloads` permission is declared but the editor saves via an in-page browser download.
- Review the dependency URLs and scripts before running; this is source code, not a Chrome Web Store release.

## Dependency versions
- pdf.js 3.11.174
- pdf-lib 1.17.1

The ZIP distributes original extension code and install scripts, **not** the PDF library binaries, because network access was not available during creation.
