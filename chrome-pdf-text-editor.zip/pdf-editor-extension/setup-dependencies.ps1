$ErrorActionPreference = 'Stop'
$vendor = Join-Path $PSScriptRoot 'vendor'
New-Item -ItemType Directory -Path $vendor -Force | Out-Null
$libs = @{
 'pdf.min.js' = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js'
 'pdf.worker.min.js' = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js'
 'pdf-lib.min.js' = 'https://unpkg.com/pdf-lib@1.17.1/dist/pdf-lib.min.js'
}
foreach($name in $libs.Keys) {
 Write-Host "Downloading $name ..."
 Invoke-WebRequest -Uri $libs[$name] -OutFile (Join-Path $vendor $name) -UseBasicParsing
}
Write-Host 'Done. In chrome://extensions, Load unpacked and select this extension folder.' -ForegroundColor Green
