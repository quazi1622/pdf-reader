#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p vendor
curl -fL 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js' -o vendor/pdf.min.js
curl -fL 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js' -o vendor/pdf.worker.min.js
curl -fL 'https://unpkg.com/pdf-lib@1.17.1/dist/pdf-lib.min.js' -o vendor/pdf-lib.min.js
echo 'Libraries installed. Open chrome://extensions > Load unpacked.'
